"use strict";
var gl;
var canvas;

var bufferId;
var day = 0;
var dayOffset = 1;
var mspf = 1000/30;
var g_last = Date.now();
var pi = Math.PI;
var orbitPath;

// TRACKBALL
var trackballMove = false;
var m_curquat;
var m_mousex = 1;
var m_mousey = 1;
var x_trans = 0;
var y_trans = 0;

var mvpMatrix; // projectMatrix * modelViewMatrix
var nMatrix; // normal matrix 
var projectionMatrix; // projection matrix
var stack = []; // matrix stack, for pushing and popping

var positionLoc;
var colorLoc;
var mvpMatrixLoc;
var mvMatrixLoc;
var nMatrixLoc;

// LIGHTING
var ambientColorUniform;
var lightPositionUniform;
var lightColorUniform;

// TEXTURE
var samplerUniform;
var textureCoordAttribute;
var textureCoordData = [];
var vertexTextureCoordBuffer;
var sunTexture;
var mercuryTexture;
var venusTexture;
var earthTexture;
var moonTexture;
var marsTexture;
var jupiterTexture;
var saturnTexture;
var uranusTexture;
var neptuneTexture;
var plutoTexture;

// scale factors
var rSunMult = 30;      // keep sun's size manageable
var rPlanetMult = 1200;  // scale planet sizes to be more visible
var scale;
var realScale = 1;

// colors
var colorSun = vec3(1.0,1.0,0.0);
var colorMercury = vec3(1.0,0.0,0.0);
var colorVenus = vec3(0.3,1.0,0.3);
var colorEarth = vec3(0.0,0.0,1.0);
var colorMoon = vec3(1.0,1.0,1.0);
var colorMars = vec3(1.0,0.27,0.0);
var colorJupiter = vec3(0.82,0.76,0.49);
var colorSaturn = vec3(1.0,0.8,0.17);
var colorUranus = vec3(0.69,0.98,1.0);
var colorNeptune = vec3(0.18,0.06,0.98);
var colorPluto = vec3(1.0,1.0,1.0);

// surface radii (km)
var rSun = 696000*2;
var rMercury = 2440;
var rVenus = 6052;
var rEarth = 6371;
var rMoon = 1737;
var rMars = 3397;
var rJupiter = 71492/4;
var rSaturn = 60268/4;
var rUranus = 25559/4;
var rNeptune = 24766/4;
var rPluto = 1150*2;

// orbital radii (km)
var orMercury = 57909050+69600000;
var orVenus = 108208000+69600000;
var orEarth = 149598261+69600000;
var orMoon = 384399;
var orMars = 227900000+69600000;
var orJupiter = 778600000*0.4+69600000;
var orSaturn = 1433000000*0.3+69600000;
var orUranus = 2873000000*0.18+69600000;
var orNeptune = 4495000000*0.14+69600000;
var orPluto = 5906000000*0.12+69600000;

// orbital periods (Earth days)
var pMercury = 88;
var pVenus = 225;
var pEarth = 365;
var pMoon = 27;
var pMars = 687;
var pJupiter = 4329*0.08;
var pSaturn = 10735*0.08;
var pUranus = 30675*0.08;
var pNeptune = 59758*0.08;
var pPluto = 90494*0.08;	

var projectionScale;

var vertexNormalAttribute;
var normalData = [];
var sphereVertexNormalBuffer;

var sphereVertexPositionData = [];
var sphereVertexPositionBuffer;

var sphereVertexIndexData = [];
var sphereVertexIndexBuffer;

window.onload = function init() {
    canvas = document.getElementById( "gl-canvas" );
    
    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }
    
    //
    //  Configure WebGL
    //
    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 0.05, 0.05, 0.05, 1.0 );
    
    gl.enable(gl.DEPTH_TEST);

    m_curquat = trackball(0, 0, 0, 0);	// initialize trackball
    
    // projection matrix
    projectionScale = scale*1.0 / ( orEarth + orMoon
                             + ( rEarth + 2 * rMoon ) * rPlanetMult );
    
    // standard orthogonal projection matrix * uniform scaling matrix
    projectionMatrix = mult(scalem(projectionScale,projectionScale,projectionScale), rotateX(-30));	// rotate orrery 30 degrees
    projectionMatrix = mult(projectionMatrix, ortho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0));

    setupSphere();
    
    //  Load shaders and initialize attribute buffers
    
    var program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );
    
    // initialize unscaled orbit path template
    var step = 48;
    orbitPath = [];
    var i;
    for(i=0; i<step; i++) {
	orbitPath[i] = vec3(Math.cos(2*i*pi/step), 0.0, Math.sin(2*i*pi/step));
    }
    orbitPath[step] = vec3(Math.cos(0), 0.0, Math.sin(0));

    // Load the data into the GPU

    bufferId = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(orbitPath), gl.STATIC_DRAW );

    sphereVertexPositionBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, sphereVertexPositionBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(sphereVertexPositionData), gl.STATIC_DRAW);

    sphereVertexNormalBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, sphereVertexNormalBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normalData), gl.STATIC_DRAW);
    
    sphereVertexIndexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, sphereVertexIndexBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(sphereVertexIndexData), gl.STATIC_DRAW);

    // initialize the texture buffer
    vertexTextureCoordBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexTextureCoordBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(textureCoordData), gl.STATIC_DRAW);

    // Associate out shader variables with our data buffer
    
    positionLoc = gl.getAttribLocation( program, "vPosition" );
    gl.enableVertexAttribArray( positionLoc );
    
    vertexNormalAttribute = gl.getAttribLocation(program, "vNormal");
    gl.enableVertexAttribArray(vertexNormalAttribute);
    
    colorLoc = gl.getUniformLocation( program, "vColor" );
    mvpMatrixLoc = gl.getUniformLocation( program, "mvpMatrix" );
    mvMatrixLoc = gl.getUniformLocation( program, "mvMatrix" );
    nMatrixLoc = gl.getUniformLocation ( program, "nMatrix" );

    // lighting locations
    ambientColorUniform = gl.getUniformLocation(program, "uAmbientColor");
    lightPositionUniform = gl.getUniformLocation(program, "uLightPosition");
    lightColorUniform = gl.getUniformLocation(program, "uLightColor");

    // texture locations
    samplerUniform = gl.getUniformLocation(program, "uSampler");
    textureCoordAttribute = gl.getAttribLocation(program, "aTextureCoord");
    gl.enableVertexAttribArray(textureCoordAttribute);

    canvas.addEventListener("mousedown", function(event){	// start of click
        m_mousex = event.clientX - event.target.getBoundingClientRect().left;
        m_mousey = event.clientY - event.target.getBoundingClientRect().top;
        trackballMove = true;
    });

    canvas.addEventListener("mouseup", function(event){	// end of click
        trackballMove = false;
    });

    canvas.addEventListener("mousemove", function(event){
      if (trackballMove) {	// if is a drag click
        var x = event.clientX - event.target.getBoundingClientRect().left;
        var y = event.clientY - event.target.getBoundingClientRect().top;
        mouseMotion(x, y);
      }
    } );

    // initialize textures for each body
    // sun
    sunTexture = gl.createTexture();
    sunTexture.image = new Image();
    sunTexture.image.src = "sun.jpg";
    sunTexture.image.onload = function () {
        handleLoadedTexture(sunTexture)
    }
    // mercury
    mercuryTexture = gl.createTexture();
    mercuryTexture.image = new Image();
    mercuryTexture.image.src = "mercury.jpg";
    mercuryTexture.image.onload = function () {
        handleLoadedTexture(mercuryTexture)
    }
    // venus
    venusTexture = gl.createTexture();
    venusTexture.image = new Image();
    venusTexture.image.src = "venus.jpg";
    venusTexture.image.onload = function () {
        handleLoadedTexture(venusTexture)
    }
    // earth
    earthTexture = gl.createTexture();
    earthTexture.image = new Image();
    earthTexture.image.src = "earth.jpg";
    earthTexture.image.onload = function () {
        handleLoadedTexture(earthTexture)
    }
    // all moons in system use this texture
    moonTexture = gl.createTexture();
    moonTexture.image = new Image();
    moonTexture.image.src = "moon.jpg";
    moonTexture.image.onload = function () {
        handleLoadedTexture(moonTexture)
    }
    // mars
    marsTexture = gl.createTexture();
    marsTexture.image = new Image();
    marsTexture.image.src = "mars.jpg";
    marsTexture.image.onload = function () {
        handleLoadedTexture(marsTexture)
    }
    // jupiter
    jupiterTexture = gl.createTexture();
    jupiterTexture.image = new Image();
    jupiterTexture.image.src = "jupiter.jpg";
    jupiterTexture.image.onload = function () {
        handleLoadedTexture(jupiterTexture)
    }
    // saturn
    saturnTexture = gl.createTexture();
    saturnTexture.image = new Image();
    saturnTexture.image.src = "saturn.jpg";
    saturnTexture.image.onload = function () {
        handleLoadedTexture(saturnTexture)
    }
    // uranus
    uranusTexture = gl.createTexture();
    uranusTexture.image = new Image();
    uranusTexture.image.src = "uranus.jpg";
    uranusTexture.image.onload = function () {
        handleLoadedTexture(uranusTexture)
    }
    // neptune
    neptuneTexture = gl.createTexture();
    neptuneTexture.image = new Image();
    neptuneTexture.image.src = "neptune.jpg";
    neptuneTexture.image.onload = function () {
        handleLoadedTexture(neptuneTexture)
    }
    // pluto
    plutoTexture = gl.createTexture();
    plutoTexture.image = new Image();
    plutoTexture.image.src = "pluto.jpg";
    plutoTexture.image.onload = function () {
        handleLoadedTexture(plutoTexture)
    }
    // render scene
    render();
    
};

// keyboard interactions, move left, right, up or down
document.onkeydown = function(e) {
    switch (e.keyCode) {
        case 37:
            if (x_trans > -6100000000)
	    x_trans += -100000000;
            break;
        case 38:
            if (y_trans < 6100000000)
	    y_trans += 100000000;
            break;
        case 39:
            if (x_trans < 6100000000)
	    x_trans += 100000000;
            break;
        case 40:
            if (y_trans > -6100000000)
	    y_trans += -100000000;
            break;
    }
};

// for trackball feature
function mouseMotion(x, y) {
        var lastquat;
        if (m_mousex != x || m_mousey != y)
        {
            lastquat = trackball(
                  (2.0*m_mousex - canvas.width) / canvas.width,
                  (canvas.height - 2.0*m_mousey) / canvas.height,
                  (2.0*x - canvas.width) / canvas.width,
                  (canvas.height - 2.0*y) / canvas.height);
            m_curquat = add_quats(lastquat, m_curquat);
            m_mousex = x;
            m_mousey = y;
        }
}

// set up texture
function handleLoadedTexture(texture) {
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, texture.image);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.bindTexture(gl.TEXTURE_2D, null);
}

// increase button functionality
function incDPF() {
	dayOffset *= 2;
}

// decrease button functionality
function decDPF() {
	dayOffset /= 2;
}

function countDay() {		// update text showing number of days elapsed
    var text = document.getElementById("dayCount");
    if ((document.getElementById("dayoff").checked)) {
	text.innerHTML = "";
    }
    else {
	text.innerHTML = "Day " + day;
    }
}

function changeScaling(scaled) {
	if (document.getElementById("scaleon").checked) {	// illustrated view
		// surface radii (km)
		rSun = 696000*2;
		rMercury = 2440;
		rVenus = 6052;
		rEarth = 6371;
		rMoon = 1737;
		rMars = 3397;
		rJupiter = 71492/4;
		rSaturn = 60268/4;
		rUranus = 25559/4;
		rNeptune = 24766/4;
		rPluto = 1150*2;

		// orbital radii (km)
		orMercury = 57909050+69600000;
		orVenus = 108208000+69600000;
		orEarth = 149598261+69600000;
		orMoon = 384399;
		orMars = 227900000+69600000;
		orJupiter = 778600000*0.4+69600000;
		orSaturn = 1433000000*0.3+69600000;
		orUranus = 2873000000*0.18+69600000;
		orNeptune = 4495000000*0.14+69600000;
		orPluto = 5906000000*0.12+69600000;

		// orbital periods (Earth days)
		pMercury = 88;
		pVenus = 225;
		pEarth = 365;
		pMoon = 27;
		pMars = 687;
		pJupiter = 4329*0.08;
		pSaturn = 10735*0.08;
		pUranus = 30675*0.08;
		pNeptune = 59758*0.08;
		pPluto = 90494*0.08;	
		var input = document.getElementById("scaling");
		input.setAttribute("min", 10);	// modify min of slider to change the frame to fit the view
	}
	else {	// "real scale"
		// surface radii (km)
		rSun = 696000*10;
		rMercury = 2440;
		rVenus = 6052;
		rEarth = 6371;
		rMoon = 1737;
		rMars = 3397;
		rJupiter = 71492;
		rSaturn = 60268;
		rUranus = 25559;
		rNeptune = 24766;
		rPluto = 1150;

		// orbital radii (km)
		orMercury = 57909050+4*69600000;
		orVenus = 108208000+4*69600000;
		orEarth = 149598261+4*69600000;
		orMoon = 384399;
		orMars = 227900000+4*69600000;
		orJupiter = 778600000+4*69600000;
		orSaturn = 1433000000+4*69600000;
		orUranus = 2873000000+4*69600000;
		orNeptune = 4495000000+4*69600000;
		orPluto = 5906000000+4*69600000;

		// orbital periods (Earth days)
		pMercury = 88;
		pVenus = 225;
		pEarth = 365;
		pMoon = 27;
		pMars = 687;
		pJupiter = 4329;
		pSaturn = 10735;
		pUranus = 30675;
		pNeptune = 59758;
		pPluto = 90494;
		var input = document.getElementById("scaling");
		input.setAttribute("min", 2.5); // modify min of slider to change the frame to fit the view
	}
}

function setupSphere() {
    var latitudeBands = 30;
    var longitudeBands = 30;
    var radius = 1.0;
    
    for (var latNumber=0; latNumber <= latitudeBands; latNumber++) {
        var theta = latNumber * pi / latitudeBands;
        var sinTheta = Math.sin(theta);
        var cosTheta = Math.cos(theta);
        
        for (var longNumber=0; longNumber <= longitudeBands; longNumber++) {
            var phi = longNumber * 2 * pi / longitudeBands;
            var sinPhi = Math.sin(phi);
            var cosPhi = Math.cos(phi);
            
            var x = cosPhi * sinTheta;
            var y = cosTheta;
            var z = sinPhi * sinTheta;
            var u = 1 - (longNumber / longitudeBands);
            var v = 1 - (latNumber / latitudeBands);
            
            normalData.push(x);
            normalData.push(y);
            normalData.push(z);
            sphereVertexPositionData.push(radius * x);
            sphereVertexPositionData.push(radius * y);
            sphereVertexPositionData.push(radius * z);
            textureCoordData.push(u);
            textureCoordData.push(v);
        }
    }
    
    for (var latNumber=0; latNumber < latitudeBands; latNumber++) {
        for (var longNumber=0; longNumber < longitudeBands; longNumber++) {
            var first = (latNumber * (longitudeBands + 1)) + longNumber;
            var second = first + longitudeBands + 1;
            sphereVertexIndexData.push(first);
            sphereVertexIndexData.push(second);
            sphereVertexIndexData.push(first + 1);
            
            sphereVertexIndexData.push(second);
            sphereVertexIndexData.push(second + 1);
            sphereVertexIndexData.push(first + 1);
        }
    }
};

function drawSphere(color, size, texture) {
    // set uniforms
    gl.uniform3fv( colorLoc, color );
    
    // get the matrix at the top of stack
    var topm = stack[stack.length-1];
    mvpMatrix = mult(topm, scalem(size, size, size));
    gl.uniformMatrix4fv(mvMatrixLoc, false, flatten(mvpMatrix));	// pass model view to shader for lighting
    // pass normal matrix for lighting purposes
    nMatrix = normalMatrix(mvpMatrix, true); // return 3 by 3 normal matrix maybe should be mvMatrix not mvpMatrix
    gl.uniformMatrix3fv(nMatrixLoc, false, flatten(nMatrix));
    mvpMatrix = mult(projectionMatrix, mvpMatrix);
    gl.uniformMatrix4fv(mvpMatrixLoc, false, flatten(mvpMatrix) );
    
    // draw the sphere with texture
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.uniform1i(samplerUniform, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, sphereVertexPositionBuffer);
    gl.vertexAttribPointer(positionLoc, 3, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, vertexTextureCoordBuffer);
    gl.vertexAttribPointer(textureCoordAttribute, 2, gl.FLOAT, false, 0, 0);
    
    gl.bindBuffer(gl.ARRAY_BUFFER, sphereVertexNormalBuffer);
    gl.vertexAttribPointer(vertexNormalAttribute, 3, gl.FLOAT, false, 0, 0);
    
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, sphereVertexIndexBuffer);
    gl.drawElements(gl.TRIANGLES, sphereVertexIndexData.length, gl.UNSIGNED_SHORT, 0);
    
    //gl.uniform1i(samplerUniform, 0);

};

function drawBodies() { 
    var size;
    // Sun
    size = rSun * rSunMult;
    stack.push(mat4());
    drawSphere( colorSun, size, sunTexture );
    stack.pop();

    // Mercury
    size = rMercury * rPlanetMult;
    var merc = mult(mat4(),translate(orMercury*Math.cos(-day*2*pi/pMercury),0,orMercury*Math.sin(-day*2*pi/pMercury)));
    stack.push(merc);
    drawSphere( colorMercury, size, mercuryTexture );
    stack.pop();

    // Venus
    size = rVenus * rPlanetMult;
    var venus = mult(mat4(),translate(orVenus*Math.cos(-day*2*pi/pVenus),0,orVenus*Math.sin(-day*2*pi/pVenus)));
    stack.push(venus);
    drawSphere( colorVenus, size, venusTexture );
    stack.pop();

    // Earth
    var earth = mult(mat4(),translate(orEarth*Math.cos(-day*2*pi/pEarth),0,orEarth*Math.sin(-day*2*pi/pEarth)));
    stack.push(earth);
    	// Moon
    	size = rMoon * rPlanetMult;
    	var moon = mult(earth,translate((orMoon+rEarth)*rSunMult*Math.cos(-day*2*pi/pMoon),0,(orMoon+rEarth)*rSunMult*Math.sin(-day*2*pi/pMoon)));
    	stack.push(moon);
    	drawSphere( colorMoon, size, moonTexture );
    	stack.pop();
    size = rEarth * rPlanetMult;
    drawSphere( colorEarth, size, earthTexture );
    stack.pop();

    // Mars
    size = rMars * rPlanetMult;
    var mars = mult(mat4(),translate(orMars*Math.cos(-day*2*pi/pMars),0,orMars*Math.sin(-day*2*pi/pMars)));
    stack.push(mars);
    drawSphere( colorMars, size, marsTexture );
    stack.pop();

    // Jupiter
    var jupiter = mult(mat4(),translate(orJupiter*Math.cos(-day*2*pi/pJupiter),0,orJupiter*Math.sin(-day*2*pi/pJupiter)));
    stack.push(jupiter);
    	// Io
    	size = rMoon * rPlanetMult;
    	var moon = mult(jupiter,translate((orMoon+30*rJupiter)*rSunMult*Math.cos(-day*2*pi/pMoon),0,(orMoon+30*rJupiter)*rSunMult*Math.sin(-day*2*pi/pMoon)));
    	stack.push(moon);
    	drawSphere( colorMoon, size, moonTexture );
    	stack.pop();
    	// Europa
    	size = rMoon * 0.8 * rPlanetMult;
    	var moon = mult(jupiter,translate((orMoon+35*rJupiter)*rSunMult*Math.cos(-(day+8)*2*pi/pMoon),0,(orMoon+35*rJupiter)*rSunMult*Math.sin(-(day+8)*2*pi/pMoon)));
    	stack.push(moon);
    	drawSphere( colorMoon, size, moonTexture );
    	stack.pop();
    	// Ganymede
    	size = rMoon * 1.4 * rPlanetMult;
    	var moon = mult(jupiter,translate((orMoon+40*rJupiter)*rSunMult*Math.cos(-(day+16)*2*pi/pMoon),0,(orMoon+40*rJupiter)*rSunMult*Math.sin(-(day+16)*2*pi/pMoon)));
    	stack.push(moon);
    	drawSphere( colorMoon, size, moonTexture );
    	stack.pop();
    	// Callisto
    	size = rMoon * 1.2 * rPlanetMult;
    	var moon = mult(jupiter,translate((orMoon+45*rJupiter)*rSunMult*Math.cos(-(day+24)*2*pi/pMoon),0,(orMoon+40*rJupiter)*rSunMult*Math.sin(-(day+24)*2*pi/pMoon)));
    	stack.push(moon);
    	drawSphere( colorMoon, size, moonTexture );
    	stack.pop();
    size = rJupiter * rPlanetMult;
    drawSphere( colorJupiter, size, jupiterTexture );
    stack.pop();

    // Saturn
    var saturn = mult(mat4(),translate(orSaturn*Math.cos(-day*2*pi/pSaturn),0,orSaturn*Math.sin(-day*2*pi/pSaturn)));
    stack.push(saturn);
    	// Titan
    	size = rMoon * 1.4 * rPlanetMult;
    	var moon = mult(saturn,translate((orMoon+40*rSaturn)*rSunMult*Math.cos(-(day)*2*pi/pMoon),0,(orMoon+40*rSaturn)*rSunMult*Math.sin(-(day)*2*pi/pMoon)));
    	stack.push(moon);
    	drawSphere( colorMoon, size, moonTexture );
    	stack.pop();
    size = rSaturn * rPlanetMult;
    drawSphere( colorSaturn, size, saturnTexture );
    stack.pop();

    // Uranus
    size = rUranus * rPlanetMult;
    var uranus = mult(mat4(),translate(orUranus*Math.cos(-day*2*pi/pUranus),0,orUranus*Math.sin(-day*2*pi/pUranus)));
    stack.push(uranus);
    drawSphere( colorUranus, size, uranusTexture );
    stack.pop();

    // Neptune
    size = rNeptune * rPlanetMult;
    var neptune = mult(mat4(),translate(orNeptune*Math.cos(-day*2*pi/pNeptune),0,orNeptune*Math.sin(-day*2*pi/pNeptune)));
    stack.push(neptune);
    drawSphere( colorNeptune, size, neptuneTexture );
    stack.pop();

    // Pluto
    size = rPluto * rPlanetMult;
    var pluto = mult(mat4(),translate(orPluto*Math.cos(-day*2*pi/pPluto),0,orPluto*Math.sin(-day*2*pi/pPluto)));
    stack.push(pluto);
    drawSphere( colorPluto, size, plutoTexture );
    stack.pop();
};

function drawCircle(size) {	// similar to drawSphere function provided

    // set uniforms
    gl.uniform3fv( colorLoc, vec3(0.0, 0.0, 0.0) );
    
    // get the matrix at the top of stack
    var topm = stack[stack.length-1];
    mvpMatrix = mult(topm, scalem(size, size, size));
    mvpMatrix = mult(projectionMatrix, mvpMatrix);
    gl.uniformMatrix4fv(mvpMatrixLoc, false, flatten(mvpMatrix) );
    
    // draw the sphere
    gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
    gl.vertexAttribPointer(positionLoc, 3, gl.FLOAT, false, 0, 0);
    gl.drawArrays(gl.LINE_STRIP, 0, 49);

};

function drawOrbits() {
    // Mercury orbit
    stack.push(mat4());
    drawCircle(orMercury);
    stack.pop();

    // Venus orbit
    stack.push(mat4());
    drawCircle(orVenus);
    stack.pop();

    // Earth orbit
    stack.push(mat4());
	// Moon orbit
	stack.push(mult(mat4(),translate(orEarth*Math.cos(-day*2*pi/pEarth),0,orEarth*Math.sin(-day*2*pi/pEarth))));
    	drawCircle((orMoon+rEarth)*rSunMult);
    	stack.pop();
    drawCircle(orEarth);
    stack.pop();

    // Mars orbit
    stack.push(mat4());
    drawCircle(orMars);
    stack.pop();

    // Jupiter orbit
    stack.push(mat4());
	// Io
	stack.push(mult(mat4(),translate(orJupiter*Math.cos(-day*2*pi/pJupiter),0,orJupiter*Math.sin(-day*2*pi/pJupiter))));
    	drawCircle((orMoon+30*rJupiter)*rSunMult);
    	stack.pop();
	// Europa
	stack.push(mult(mat4(),translate(orJupiter*Math.cos(-day*2*pi/pJupiter),0,orJupiter*Math.sin(-day*2*pi/pJupiter))));
    	drawCircle((orMoon+35*rJupiter)*rSunMult);
    	stack.pop();
	// Ganymede
	stack.push(mult(mat4(),translate(orJupiter*Math.cos(-day*2*pi/pJupiter),0,orJupiter*Math.sin(-day*2*pi/pJupiter))));
    	drawCircle((orMoon+40*rJupiter)*rSunMult);
    	stack.pop();
	// Callisto
	stack.push(mult(mat4(),translate(orJupiter*Math.cos(-day*2*pi/pJupiter),0,orJupiter*Math.sin(-day*2*pi/pJupiter))));
    	drawCircle((orMoon+45*rJupiter)*rSunMult);
    	stack.pop();
    drawCircle(orJupiter);
    stack.pop();

    // Saturn orbit
    stack.push(mat4());
	// Titan
	stack.push(mult(mat4(),translate(orSaturn*Math.cos(-day*2*pi/pSaturn),0,orSaturn*Math.sin(-day*2*pi/pSaturn))));
    	drawCircle((orMoon+40*rSaturn)*rSunMult);
    	stack.pop();
    drawCircle(orSaturn);
    stack.pop();

    // Uranus orbit
    stack.push(mat4());
    drawCircle(orUranus);
    stack.pop();

    // Neptune orbit
    stack.push(mat4());
    drawCircle(orNeptune);
    stack.pop();

    // Pluto orbit
    stack.push(mat4());
    drawCircle(orPluto);
    stack.pop();
};

function drawAll() {
    // lighting data 
    gl.uniform3f(ambientColorUniform, 0.2, 0.2, 0.2);
        
    var lightPosition = [0.0, 0.0, 0.0];
    gl.uniform3fv(lightPositionUniform, lightPosition); // light position in the world space
        
    gl.uniform3f(lightColorUniform, 1.0, 1.0, 1.0);

    // projection matrix
    projectionScale = scale*1.0 / ( orEarth + orMoon
                             + ( rEarth + 2 * rMoon ) * rPlanetMult );
    
    // standard orthogonal projection matrix * uniform scaling matrix
    projectionMatrix = mult(scalem(projectionScale,projectionScale,projectionScale), rotateX(-30));	// rotate orrery 30 degrees
    projectionMatrix = mult(projectionMatrix, translate(-x_trans, -y_trans, 0));
    projectionMatrix = mult(projectionMatrix, ortho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0));

    var m_inc = build_rotmatrix(m_curquat);
    var m_mv = mult(m_inc, mat4());
    m_mv = mult(translate(0.0, 0.0, -6.0), m_mv);

    projectionMatrix = mult(projectionMatrix, m_mv);

    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT );
    if (!(document.getElementById("orbitoff").checked)) {	// orbit display radio button functionality
	drawOrbits();
    }
    drawBodies();	// draw planets
    
};

function render() {
    scale = document.getElementById("scaling").value/(40);
    var now = Date.now();		// get current time
    var elapsed = now - g_last;		// get elapsed time
    if (!(document.getElementById("animateoff").checked)) {	// animate radio button functionality
    	if (elapsed > mspf) {		// set fps to 30
	    day += dayOffset;
    	    g_last = now;		// set past time to new past time
    	}
    }
    countDay();		// update text of # of days and implement day radio button functionality
    drawAll();
    requestAnimationFrame(render, canvas);
};
